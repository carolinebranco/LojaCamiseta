let cartItems = [];
let totalPrice = 0;

function addToCart(itemName, itemPrice, itemSize) {
  cartItems.push({ name: itemName, price: itemPrice, size: itemSize });
  totalPrice += itemPrice;

  updateCart();
}

function getSize(selectId) {
  const selectElement = document.getElementById(selectId);
  return selectElement.value;
}

function updateCart() {
  const cartItemsElement = document.getElementById('cart-items');
  const totalPriceElement = document.getElementById('total-price');

  cartItemsElement.innerHTML = '';

  cartItems.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} (Tamanho: ${item.size}) - R$ ${item.price.toFixed(2)}`;
    cartItemsElement.appendChild(li);
  });

  totalPriceElement.textContent = `Total: R$ ${totalPrice.toFixed(2)}`;
}

function clearCart() {
  cartItems = [];
  totalPrice = 0;

  updateCart();
}

function checkout() {
  if (cartItems.length === 0) {
    alert('Seu carrinho está vazio. Adicione itens antes de finalizar a compra.');
  } else {
    alert('Compra finalizada! Obrigado por comprar conosco.');
    clearCart();
  }
}